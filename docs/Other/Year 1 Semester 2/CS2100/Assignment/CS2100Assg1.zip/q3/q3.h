void print_bits(int16_t);
int16_t float_to_fixed(float);
float fixed_to_float(int16_t);
int16_t negate(int16_t);
int16_t add(int16_t, int16_t);
int16_t subtract(int16_t, int16_t);
